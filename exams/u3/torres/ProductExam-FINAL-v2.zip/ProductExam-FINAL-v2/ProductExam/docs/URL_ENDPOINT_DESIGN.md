# URL (URI/Endpoint) Design and Web Page URL

## Web Page URL

### Local development

```text
http://localhost:3016/
```

### Cloud deployment

```text
http://3.131.36.236/
```

AWS EC2 instance:

```text
i-0105e9487a247358b
```

## Base API URL

### Local development

```text
http://localhost:3016/api
```

### Cloud deployment

```text
http://3.131.36.236/api
```

## URI/Endpoint Design

| Method | URI | Purpose |
|---|---|---|
| `GET` | `/api/health` | Verify that the Node.js backend is online. |
| `GET` | `/api/products` | Return every product currently stored in the product array. |
| `GET` | `/api/products/:id` | Find one product by its numeric ID. |
| `POST` | `/api/cart/total` | Validate five product objects, store them, and calculate their total price. |
| `POST` | `/api/products/:id/iva` | Find one product and calculate only its IVA amount. |
| `POST` | `/api/products/:id/expiration` | Find one product and calculate the days remaining until its expiration date. |

## Request Designs

### Calculate the five-product cart total

```http
POST /api/cart/total
Content-Type: application/json
```

```json
{
  "products": [
    { "id": 1, "name": "Milk", "price": 3.50 },
    { "id": 2, "name": "Yogurt", "price": 2.00 },
    { "id": 3, "name": "Bread", "price": 4.25 },
    { "id": 4, "name": "Cheese", "price": 8.50 },
    { "id": 5, "name": "Eggs", "price": 6.00 }
  ]
}
```

### Calculate one product's IVA amount

```http
POST /api/products/1/iva
Content-Type: application/json
```

```json
{
  "ivaRate": 15
}
```

### Calculate one product's expiration time

```http
POST /api/products/1/expiration
Content-Type: application/json
```

```json
{
  "day": 31,
  "month": 12,
  "year": 2026
}
```
