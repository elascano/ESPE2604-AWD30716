# AWS EC2 Deployment Guide

This guide prepares the Product Exam system for its Ubuntu-based AWS EC2 instance.

```text
Instance ID: i-0105e9487a247358b
Public IPv4: 3.131.36.236
Public DNS: ec2-3-131-36-236.us-east-2.compute.amazonaws.com
Region: us-east-2
Application port: 3016
```

## 1. EC2 Requirements

- Ubuntu Server LTS.
- A small instance such as `t2.micro` or `t3.micro`.
- An SSH key pair.
- A security group with these inbound rules:

| Type | Port | Source |
|---|---:|---|
| SSH | `22` | Administrator public IP only |
| Custom TCP | `3016` | Required client IPs, or temporarily `0.0.0.0/0` |
| HTTP | `80` | `0.0.0.0/0` when Nginx is enabled |

## 2. Connect to the Instance

```bash
ssh -i YOUR_KEY.pem ubuntu@3.131.36.236
```

## 3. Install Node.js, Git, Nginx, and PM2

```bash
sudo apt update
sudo apt install -y git nginx curl
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pm2
```

Verify the tools:

```bash
node --version
npm --version
pm2 --version
```

## 4. Upload the Project

Using Git:

```bash
git clone YOUR_REPOSITORY_URL
cd YOUR_REPOSITORY/ProductExam/backend
```

Using SCP:

```bash
scp -i YOUR_KEY.pem -r ProductExam ubuntu@3.131.36.236:/home/ubuntu/
ssh -i YOUR_KEY.pem ubuntu@3.131.36.236
cd /home/ubuntu/ProductExam/backend
```

## 5. Install and Test

```bash
npm ci --omit=dev
npm test
```

## 6. Start with PM2

The provided `ecosystem.config.cjs` fixes the service port at `3016` and enables automatic restarts.

```bash
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

Run the command printed by `pm2 startup`, then verify:

```bash
pm2 status
pm2 logs product-exam
curl http://127.0.0.1:3016/api/health
```

## 7. Optional Nginx Reverse Proxy

Create `/etc/nginx/sites-available/product-exam`:

```nginx
server {
    listen 80;
    server_name 3.131.36.236 ec2-3-131-36-236.us-east-2.compute.amazonaws.com;

    location / {
        proxy_pass http://127.0.0.1:3016;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/product-exam /etc/nginx/sites-enabled/product-exam
sudo nginx -t
sudo systemctl restart nginx
```

With Nginx, the web page will be available at:

```text
http://3.131.36.236/
```

Without Nginx:

```text
http://3.131.36.236:3016/
```

## 8. Deployment Verification

```bash
curl http://127.0.0.1:3016/api/health
curl http://127.0.0.1:3016/api/products
pm2 status
sudo systemctl status nginx
```
