# Class Diagram

The application follows a small layered architecture. HTTP responsibilities stay in the controller, business rules stay in the service and domain classes, and product storage is isolated behind a repository.

```mermaid
classDiagram
    class Product {
        +Number id
        +String name
        +Number price
        +parseId(value)$ Number
        +parseName(value)$ String
        +parsePrice(value)$ Number
    }

    class ShoppingCart {
        +Product[] products
        +calculateTotal() Number
    }

    class SQLiteProductRepository {
        -DatabaseSync database
        -Product[] products
        +findAll() Product[]
        +findById(id) Product
        +replaceAll(products) Product[]
    }

    class ProductService {
        -SQLiteProductRepository productRepository
        -Number defaultIvaRate
        +getProducts() Product[]
        +getProduct(productId) Product
        +calculateCartTotal(products) Object
        +calculateIva(productId, ivaRate) Object
        +calculateExpiration(productId, date) Object
    }

    class ProductController {
        -ProductService productService
        +list(request, response)
        +find(request, response)
        +calculateCartTotal(request, response)
        +calculateIva(request, response)
        +calculateExpiration(request, response)
    }

    class ValidationError {
        +Number statusCode
    }

    class NotFoundError {
        +Number statusCode
    }

    ShoppingCart "1" o-- "5" Product
    SQLiteProductRepository o-- Product
    ProductService --> ShoppingCart
    ProductService --> Product
    ProductService --> SQLiteProductRepository
    ProductService ..> ValidationError
    ProductService ..> NotFoundError
    ProductController --> ProductService
```

## Responsibility Summary

- `Product`: validates and represents one product.
- `ShoppingCart`: enforces the five-product rule and calculates the total.
- `SQLiteProductRepository`: persists products in SQLite and provides lookup operations.
- `ProductService`: coordinates use cases and performs IVA and expiration calculations.
- `ProductController`: translates HTTP requests into service calls.
- `ValidationError` and `NotFoundError`: provide meaningful HTTP error responses.
