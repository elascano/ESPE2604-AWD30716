# Rubric Checklist

## Clean Code — 10 points

- Layered frontend and backend structure.
- Business rules isolated in `backend/src/business-rules`.
- Intention-revealing class and function names.
- Controller, service, repository, and domain responsibilities separated.
- Centralized validation and error handling.
- Automated unit and API tests.

## Database — 5 points

- SQLite persistent database.
- Automatic database and table creation.
- Product schema with primary key, required fields, and non-negative price constraint.
- Repository pattern keeps database code outside the business rules.
- Database location: `backend/data/product-exam.db`.

## Backend — 10 points

- Node.js and Express REST API.
- Shopping cart total calculated by the backend.
- IVA amount calculated by the backend.
- Expiration time calculated by the backend.
- Input validation and meaningful HTTP responses.
- PM2 production process deployed on AWS EC2.

## Frontend — 10 points

- Responsive supermarket-oriented visual design.
- Five-product shopping cart form.
- IVA calculator.
- Expiration-time calculator with separate day, month, and year inputs.
- Frontend communicates with the backend through `fetch`.
- Public deployment: `http://3.131.36.236/`.

## Verification

- Node automated tests: 10 passed.
- Postman/Newman requests: 6 passed.
- Postman/Newman assertions: 14 passed.
- Failed API tests: 0.
