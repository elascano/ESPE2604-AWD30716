const test = require("node:test");
const assert = require("node:assert/strict");
const Product = require("../src/business-rules/domain/Product");
const InMemoryProductRepository = require("../src/repositories/InMemoryProductRepository");
const ProductService = require("../src/business-rules/services/ProductService");

function createService(products = []) {
  const repository = new InMemoryProductRepository(products);
  return new ProductService(repository, 15);
}

test("calculates the total of exactly five products", () => {
  const service = createService();
  const result = service.calculateCartTotal([
    { id: 1, name: "One", price: 10 },
    { id: 2, name: "Two", price: 20 },
    { id: 3, name: "Three", price: 30 },
    { id: 4, name: "Four", price: 40 },
    { id: 5, name: "Five", price: 50 }
  ]);

  assert.equal(result.productCount, 5);
  assert.equal(result.total, 150);
});

test("rejects a cart that does not contain five products", () => {
  const service = createService();

  assert.throws(
    () => service.calculateCartTotal([{ id: 1, name: "Only one", price: 10 }]),
    /exactly 5 products/
  );
});

test("calculates only the IVA amount for one product", () => {
  const service = createService([new Product({ id: 1, name: "Milk", price: 1000 })]);
  const result = service.calculateIva(1);

  assert.equal(result.ivaRate, 15);
  assert.equal(result.ivaAmount, 150);
  assert.equal(result.product.price, 1000);
});

test("calculates the number of remaining days using a calendar date", () => {
  const service = createService([new Product({ id: 1, name: "Milk", price: 5 })]);
  const result = service.calculateExpiration(
    1,
    { day: 20, month: 1, year: 2026 },
    new Date(2026, 0, 15)
  );

  assert.equal(result.daysRemaining, 5);
  assert.equal(result.status, "available");
  assert.equal(result.expirationDate, "2026-01-20");
});

test("rejects impossible expiration dates", () => {
  const service = createService([new Product({ id: 1, name: "Milk", price: 5 })]);

  assert.throws(
    () => service.calculateExpiration(1, { day: 31, month: 2, year: 2026 }),
    /not valid/
  );
});

test("reports an expired product with a negative day count", () => {
  const service = createService([new Product({ id: 1, name: "Milk", price: 5 })]);
  const result = service.calculateExpiration(
    1,
    { day: 10, month: 1, year: 2026 },
    new Date(2026, 0, 15)
  );

  assert.equal(result.daysRemaining, -5);
  assert.equal(result.status, "expired");
});
