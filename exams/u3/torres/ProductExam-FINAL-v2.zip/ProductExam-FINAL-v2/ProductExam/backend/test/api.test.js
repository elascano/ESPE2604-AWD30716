const test = require("node:test");
const assert = require("node:assert/strict");
const createApp = require("../src/app");

async function withServer(callback) {
  const server = createApp({ databasePath: ":memory:" }).listen(0);
  await new Promise((resolve) => server.once("listening", resolve));
  const address = server.address();

  try {
    await callback(`http://127.0.0.1:${address.port}`);
  } finally {
    await new Promise((resolve, reject) => {
      server.close((error) => error ? reject(error) : resolve());
    });
  }
}

test("GET /api/health reports the configured application port", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/health`);
    const payload = await response.json();

    assert.equal(response.status, 200);
    assert.equal(payload.status, "ok");
    assert.equal(payload.port, 3016);
  });
});

test("POST /api/cart/total returns the server-calculated total", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/cart/total`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        products: [
          { id: 1, name: "One", price: 10 },
          { id: 2, name: "Two", price: 20 },
          { id: 3, name: "Three", price: 30 },
          { id: 4, name: "Four", price: 40 },
          { id: 5, name: "Five", price: 50 }
        ]
      })
    });
    const payload = await response.json();

    assert.equal(response.status, 200);
    assert.equal(payload.total, 150);
  });
});

test("POST /api/products/:id/iva returns only the IVA calculation", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/products/1/iva`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({})
    });
    const payload = await response.json();

    assert.equal(response.status, 200);
    assert.equal(payload.ivaRate, 15);
    assert.equal(payload.ivaAmount, 0.53);
    assert.equal(Object.hasOwn(payload, "totalPrice"), false);
  });
});

test("invalid data produces a 400 response", async () => {
  await withServer(async (baseUrl) => {
    const response = await fetch(`${baseUrl}/api/products/1/expiration`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ day: 31, month: 2, year: 2026 })
    });
    const payload = await response.json();

    assert.equal(response.status, 400);
    assert.match(payload.message, /not valid/);
  });
});
