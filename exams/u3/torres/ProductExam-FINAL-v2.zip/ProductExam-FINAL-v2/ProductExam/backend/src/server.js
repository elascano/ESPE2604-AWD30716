const config = require("./config");
const createApp = require("./app");

const app = createApp();

const server = app.listen(config.port, "0.0.0.0", () => {
  console.log(`Product Exam is running at http://localhost:${config.port}`);
});

function shutDown(signal) {
  console.log(`${signal} received. Closing the HTTP server.`);
  server.close(() => process.exit(0));
}

process.on("SIGINT", () => shutDown("SIGINT"));
process.on("SIGTERM", () => shutDown("SIGTERM"));
