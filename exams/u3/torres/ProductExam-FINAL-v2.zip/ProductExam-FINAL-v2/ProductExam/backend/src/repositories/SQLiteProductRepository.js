const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const Product = require("../business-rules/domain/Product");

class SQLiteProductRepository {
  constructor(databasePath, initialProducts = []) {
    this.ensureDatabaseDirectory(databasePath);
    this.database = new DatabaseSync(databasePath);
    this.createTable();
    this.seedWhenEmpty(initialProducts);
  }

  findAll() {
    const rows = this.database
      .prepare("SELECT id, name, price FROM products ORDER BY id")
      .all();
    return rows.map((row) => new Product(row));
  }

  findById(id) {
    const row = this.database
      .prepare("SELECT id, name, price FROM products WHERE id = ?")
      .get(id);
    return row ? new Product(row) : null;
  }

  replaceAll(products) {
    const insertProduct = this.database.prepare(
      "INSERT INTO products (id, name, price) VALUES (?, ?, ?)"
    );

    this.database.exec("BEGIN");
    try {
      this.database.exec("DELETE FROM products");
      products.forEach((product) => {
        insertProduct.run(product.id, product.name, product.price);
      });
      this.database.exec("COMMIT");
    } catch (error) {
      this.database.exec("ROLLBACK");
      throw error;
    }

    return this.findAll();
  }

  ensureDatabaseDirectory(databasePath) {
    if (databasePath === ":memory:") {
      return;
    }
    fs.mkdirSync(path.dirname(databasePath), { recursive: true });
  }

  createTable() {
    this.database.exec(`
      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        price REAL NOT NULL CHECK (price >= 0)
      )
    `);
  }

  seedWhenEmpty(initialProducts) {
    const row = this.database.prepare("SELECT COUNT(*) AS total FROM products").get();
    if (row.total === 0) {
      this.replaceAll(initialProducts);
    }
  }
}

module.exports = SQLiteProductRepository;
