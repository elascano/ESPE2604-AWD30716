const DEFAULT_PORT = 3016;
const DEFAULT_IVA_RATE = 15;

function readPositiveNumber(value, fallback) {
  const parsedValue = Number(value);
  return Number.isFinite(parsedValue) && parsedValue >= 0 ? parsedValue : fallback;
}

const config = Object.freeze({
  port: readPositiveNumber(process.env.PORT, DEFAULT_PORT),
  ivaRate: readPositiveNumber(process.env.IVA_RATE, DEFAULT_IVA_RATE)
});

module.exports = config;
