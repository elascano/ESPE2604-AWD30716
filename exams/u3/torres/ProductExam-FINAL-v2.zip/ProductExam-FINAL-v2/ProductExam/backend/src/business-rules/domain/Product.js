const ValidationError = require("../../errors/ValidationError");

class Product {
  constructor({ id, name, price }) {
    this.id = Product.parseId(id);
    this.name = Product.parseName(name);
    this.price = Product.parsePrice(price);
  }

  static parseId(value) {
    const id = Number(value);
    if (!Number.isInteger(id) || id <= 0) {
      throw new ValidationError("Product id must be a positive integer.");
    }
    return id;
  }

  static parseName(value) {
    const name = String(value ?? "").trim();
    if (!name) {
      throw new ValidationError("Product name is required.");
    }
    return name;
  }

  static parsePrice(value) {
    const price = Number(value);
    if (!Number.isFinite(price) || price < 0) {
      throw new ValidationError("Product price must be zero or greater.");
    }
    return price;
  }
}

module.exports = Product;
