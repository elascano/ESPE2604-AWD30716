const express = require("express");

function createProductRouter(productController) {
  const router = express.Router();

  router.get("/products", productController.list);
  router.get("/products/:id", productController.find);
  router.post("/cart/total", productController.calculateCartTotal);
  router.post("/products/:id/iva", productController.calculateIva);
  router.post("/products/:id/expiration", productController.calculateExpiration);

  return router;
}

module.exports = createProductRouter;
