function notFoundHandler(request, response) {
  response.status(404).json({ message: `Route ${request.method} ${request.originalUrl} was not found.` });
}

function errorHandler(error, request, response, next) {
  if (response.headersSent) {
    return next(error);
  }

  const statusCode = error.statusCode ?? 500;
  const message = statusCode === 500 ? "An unexpected server error occurred." : error.message;
  response.status(statusCode).json({ message });
}

module.exports = { errorHandler, notFoundHandler };
