const Product = require("../domain/Product");
const ShoppingCart = require("../domain/ShoppingCart");
const NotFoundError = require("../../errors/NotFoundError");
const ValidationError = require("../../errors/ValidationError");

const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;

class ProductService {
  constructor(productRepository, defaultIvaRate) {
    this.productRepository = productRepository;
    this.defaultIvaRate = defaultIvaRate;
  }

  getProducts() {
    return this.productRepository.findAll();
  }

  getProduct(productId) {
    const id = Product.parseId(productId);
    const product = this.productRepository.findById(id);
    if (!product) {
      throw new NotFoundError(`Product ${id} was not found.`);
    }
    return product;
  }

  calculateCartTotal(productData) {
    if (!Array.isArray(productData)) {
      throw new ValidationError("Products must be provided as an array.");
    }
    const products = productData.map((data) => new Product(data));
    this.ensureUniqueIds(products);

    const cart = new ShoppingCart(products);
    this.productRepository.replaceAll(products);

    return {
      productCount: products.length,
      products,
      total: cart.calculateTotal()
    };
  }

  calculateIva(productId, requestedIvaRate) {
    const product = this.getProduct(productId);
    const ivaRate = this.parseIvaRate(requestedIvaRate);
    const ivaAmount = product.price * (ivaRate / 100);

    return {
      product,
      ivaRate,
      ivaAmount: this.roundCurrency(ivaAmount)
    };
  }

  calculateExpiration(productId, dateInput, today = new Date()) {
    const product = this.getProduct(productId);
    const expirationDate = this.parseDate(dateInput);
    const todayUtc = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate());
    const expirationUtc = expirationDate.getTime();
    const daysRemaining = Math.ceil((expirationUtc - todayUtc) / MILLISECONDS_PER_DAY);

    return {
      product,
      expirationDate: expirationDate.toISOString().slice(0, 10),
      daysRemaining,
      status: this.getExpirationStatus(daysRemaining)
    };
  }

  ensureUniqueIds(products) {
    const uniqueIds = new Set(products.map((product) => product.id));
    if (uniqueIds.size !== products.length) {
      throw new ValidationError("Every product must have a unique id.");
    }
  }

  parseIvaRate(value) {
    if (value === undefined || value === null || value === "") {
      return this.defaultIvaRate;
    }
    const ivaRate = Number(value);
    if (!Number.isFinite(ivaRate) || ivaRate < 0 || ivaRate > 100) {
      throw new ValidationError("IVA rate must be between 0 and 100.");
    }
    return ivaRate;
  }

  parseDate({ day, month, year } = {}) {
    const parsedDay = Number(day);
    const parsedMonth = Number(month);
    const parsedYear = Number(year);

    if (![parsedDay, parsedMonth, parsedYear].every(Number.isInteger)) {
      throw new ValidationError("Expiration day, month, and year must be integers.");
    }

    const date = new Date(Date.UTC(parsedYear, parsedMonth - 1, parsedDay));
    const isValid =
      parsedYear >= 1000 &&
      date.getUTCFullYear() === parsedYear &&
      date.getUTCMonth() === parsedMonth - 1 &&
      date.getUTCDate() === parsedDay;

    if (!isValid) {
      throw new ValidationError("The expiration date is not valid.");
    }
    return date;
  }

  getExpirationStatus(daysRemaining) {
    if (daysRemaining < 0) {
      return "expired";
    }
    if (daysRemaining === 0) {
      return "expires-today";
    }
    return "available";
  }

  roundCurrency(value) {
    return Math.round((value + Number.EPSILON) * 100) / 100;
  }
}

module.exports = ProductService;
