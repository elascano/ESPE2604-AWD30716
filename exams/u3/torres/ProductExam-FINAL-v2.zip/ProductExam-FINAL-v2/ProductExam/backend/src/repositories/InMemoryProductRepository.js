class InMemoryProductRepository {
  constructor(initialProducts = []) {
    this.products = [...initialProducts];
  }

  findAll() {
    return [...this.products];
  }

  findById(id) {
    return this.products.find((product) => product.id === id) ?? null;
  }

  replaceAll(products) {
    this.products = [...products];
    return this.findAll();
  }
}

module.exports = InMemoryProductRepository;
