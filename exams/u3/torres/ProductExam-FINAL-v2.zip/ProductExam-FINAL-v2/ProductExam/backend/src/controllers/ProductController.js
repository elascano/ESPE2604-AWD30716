class ProductController {
  constructor(productService) {
    this.productService = productService;
  }

  list = (request, response) => {
    response.json({ products: this.productService.getProducts() });
  };

  find = (request, response) => {
    response.json({ product: this.productService.getProduct(request.params.id) });
  };

  calculateCartTotal = (request, response) => {
    response.json(this.productService.calculateCartTotal(request.body.products));
  };

  calculateIva = (request, response) => {
    const result = this.productService.calculateIva(request.params.id, request.body.ivaRate);
    response.json(result);
  };

  calculateExpiration = (request, response) => {
    const result = this.productService.calculateExpiration(request.params.id, request.body);
    response.json(result);
  };
}

module.exports = ProductController;
