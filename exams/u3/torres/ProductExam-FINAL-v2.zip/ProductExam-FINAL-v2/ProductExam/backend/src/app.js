const path = require("node:path");
const express = require("express");
const cors = require("cors");
const config = require("./config");
const Product = require("./business-rules/domain/Product");
const ProductController = require("./controllers/ProductController");
const ProductService = require("./business-rules/services/ProductService");
const SQLiteProductRepository = require("./repositories/SQLiteProductRepository");
const createProductRouter = require("./routes/productRoutes");
const { errorHandler, notFoundHandler } = require("./middleware/errorHandler");

const initialProducts = [
  new Product({ id: 1, name: "Milk", price: 3.5 }),
  new Product({ id: 2, name: "Yogurt", price: 2 }),
  new Product({ id: 3, name: "Bread", price: 4.25 }),
  new Product({ id: 4, name: "Cheese", price: 8.5 }),
  new Product({ id: 5, name: "Eggs", price: 6 })
];

function createApp(options = {}) {
  const app = express();
  const databasePath =
    options.databasePath ?? path.join(__dirname, "..", "data", "product-exam.db");
  const repository = new SQLiteProductRepository(databasePath, initialProducts);
  const service = new ProductService(repository, config.ivaRate);
  const controller = new ProductController(service);

  app.use(cors());
  app.use(express.json({ limit: "50kb" }));
  app.use(express.static(path.join(__dirname, "..", "..", "frontend")));

  app.get("/api/health", (request, response) => {
    response.json({
      status: "ok",
      app: "Product Exam",
      port: config.port,
      author: "Carlos Alexander Torres Pincay"
    });
  });

  app.use("/api", createProductRouter(controller));
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

module.exports = createApp;
