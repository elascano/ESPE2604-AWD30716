const ValidationError = require("../../errors/ValidationError");

const REQUIRED_PRODUCT_COUNT = 5;

class ShoppingCart {
  constructor(products) {
    if (!Array.isArray(products)) {
      throw new ValidationError("Products must be provided as an array.");
    }
    if (products.length !== REQUIRED_PRODUCT_COUNT) {
      throw new ValidationError(`The shopping cart must contain exactly ${REQUIRED_PRODUCT_COUNT} products.`);
    }
    this.products = products;
  }

  calculateTotal() {
    return this.products.reduce((total, product) => total + product.price, 0);
  }
}

module.exports = ShoppingCart;
