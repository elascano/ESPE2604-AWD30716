module.exports = {
  apps: [
    {
      name: "product-exam",
      script: "src/server.js",
      cwd: __dirname,
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      watch: false,
      max_memory_restart: "300M",
      env: {
        NODE_ENV: "production",
        PORT: 3016,
        IVA_RATE: 15
      }
    }
  ]
};
