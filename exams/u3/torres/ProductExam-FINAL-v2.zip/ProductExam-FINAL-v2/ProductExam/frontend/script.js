const API_BASE_URL = "/api";
const REQUIRED_PRODUCT_COUNT = 5;

const elements = {
  productRows: document.getElementById("productRows"),
  cartForm: document.getElementById("cartForm"),
  cartTotal: document.getElementById("cartTotal"),
  cartMessage: document.getElementById("cartMessage"),
  ivaForm: document.getElementById("ivaForm"),
  ivaProduct: document.getElementById("ivaProduct"),
  ivaRate: document.getElementById("ivaRate"),
  ivaResult: document.getElementById("ivaResult"),
  expirationForm: document.getElementById("expirationForm"),
  expirationProduct: document.getElementById("expirationProduct"),
  expirationDay: document.getElementById("expirationDay"),
  expirationMonth: document.getElementById("expirationMonth"),
  expirationYear: document.getElementById("expirationYear"),
  expirationResult: document.getElementById("expirationResult")
};

const moneyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 2
});

document.addEventListener("DOMContentLoaded", initialize);

async function initialize() {
  elements.cartForm.addEventListener("submit", handleCartSubmission);
  elements.ivaForm.addEventListener("submit", handleIvaSubmission);
  elements.expirationForm.addEventListener("submit", handleExpirationSubmission);

  renderProductRows();
  await loadProducts();
}

function renderProductRows() {
  elements.productRows.innerHTML = Array.from({ length: REQUIRED_PRODUCT_COUNT }, (_, index) => {
    const position = index + 1;
    return `
      <div class="product-row">
        <input class="product-id" type="number" min="1" value="${position}" aria-label="Product ${position} ID" required>
        <input class="product-name" type="text" maxlength="80" placeholder="Product ${position}" aria-label="Product ${position} name" required>
        <input class="product-price" type="number" min="0" step="0.01" placeholder="0.00" aria-label="Product ${position} price" required>
      </div>
    `;
  }).join("");
}

async function loadProducts() {
  try {
    const payload = await requestJson(`${API_BASE_URL}/products`);
    updateProductState(payload.products);
    populateCartInputs(payload.products);
  } catch (error) {
    showCartMessage(error.message, false);
  }
}

function populateCartInputs(products) {
  const rows = [...elements.productRows.querySelectorAll(".product-row")];
  products.slice(0, REQUIRED_PRODUCT_COUNT).forEach((product, index) => {
    rows[index].querySelector(".product-id").value = product.id;
    rows[index].querySelector(".product-name").value = product.name;
    rows[index].querySelector(".product-price").value = product.price;
  });
}

async function handleCartSubmission(event) {
  event.preventDefault();
  const products = readProductsFromForm();

  try {
    const result = await requestJson(`${API_BASE_URL}/cart/total`, {
      method: "POST",
      body: JSON.stringify({ products })
    });
    updateProductState(result.products);
    elements.cartTotal.textContent = moneyFormatter.format(result.total);
    showCartMessage("The backend calculated and stored the five products.", true);
  } catch (error) {
    showCartMessage(error.message, false);
  }
}

async function handleIvaSubmission(event) {
  event.preventDefault();
  const productId = elements.ivaProduct.value;

  try {
    const result = await requestJson(`${API_BASE_URL}/products/${productId}/iva`, {
      method: "POST",
      body: JSON.stringify({ ivaRate: elements.ivaRate.value })
    });
    showResult(
      elements.ivaResult,
      "IVA amount",
      moneyFormatter.format(result.ivaAmount),
      `${result.ivaRate}% of ${result.product.name}'s ${moneyFormatter.format(result.product.price)} price.`,
      "success"
    );
  } catch (error) {
    showResult(elements.ivaResult, "IVA amount", "Calculation failed", error.message, "error");
  }
}

async function handleExpirationSubmission(event) {
  event.preventDefault();
  const productId = elements.expirationProduct.value;
  const expirationDate = {
    day: elements.expirationDay.value,
    month: elements.expirationMonth.value,
    year: elements.expirationYear.value
  };

  try {
    const result = await requestJson(`${API_BASE_URL}/products/${productId}/expiration`, {
      method: "POST",
      body: JSON.stringify(expirationDate)
    });
    showExpirationResult(result);
  } catch (error) {
    showResult(elements.expirationResult, "Selling time", "Calculation failed", error.message, "error");
  }
}

function readProductsFromForm() {
  return [...elements.productRows.querySelectorAll(".product-row")].map((row) => ({
    id: Number(row.querySelector(".product-id").value),
    name: row.querySelector(".product-name").value.trim(),
    price: Number(row.querySelector(".product-price").value)
  }));
}

function updateProductState(products) {
  const options = products
    .map((product) => `<option value="${product.id}">${escapeHtml(product.name)} · ${moneyFormatter.format(product.price)}</option>`)
    .join("");
  elements.ivaProduct.innerHTML = options;
  elements.expirationProduct.innerHTML = options;
}

function showExpirationResult(result) {
  const descriptions = {
    available: `${result.product.name} can be sold for ${result.daysRemaining} more day${result.daysRemaining === 1 ? "" : "s"}.`,
    "expires-today": `${result.product.name} expires today.`,
    expired: `${result.product.name} expired ${Math.abs(result.daysRemaining)} day${Math.abs(result.daysRemaining) === 1 ? "" : "s"} ago.`
  };
  const headline = result.status === "available"
    ? `${result.daysRemaining} days remaining`
    : result.status === "expires-today" ? "Expires today" : "Product expired";
  const style = result.status === "expired" ? "error" : "success";

  showResult(elements.expirationResult, "Selling time", headline, descriptions[result.status], style);
}

function showResult(container, label, headline, description, style) {
  container.className = `result-box ${style}`;
  container.innerHTML = `
    <span>${escapeHtml(label)}</span>
    <strong>${escapeHtml(headline)}</strong>
    <small>${escapeHtml(description)}</small>
  `;
}

function showCartMessage(message, isSuccess) {
  elements.cartMessage.textContent = message;
  elements.cartMessage.classList.toggle("success", isSuccess);
}

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options.headers
    }
  });
  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload.message || "The request could not be completed.");
  }
  return payload;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
