# System Evidence

Operational screenshots can be stored in this directory.

Suggested names:

```text
01-browser-cart-total.png
02-browser-iva.png
03-browser-expiration.png
04-api-health.png
05-api-cart-total.png
06-api-iva.png
07-api-expiration.png
08-aws-ec2-service.png
```
