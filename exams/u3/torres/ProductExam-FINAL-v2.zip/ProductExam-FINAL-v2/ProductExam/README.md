# Product Exam

Supermarket product management system with a Node.js backend and a responsive web interface.

The system supports three product operations:

1. Store exactly five product objects in a shopping cart and calculate their total.
2. Find one product and calculate only its IVA amount.
3. Find one product and calculate the number of days until its expiration date.

The application always listens on port `3016`.

Product data is persisted in a SQLite database. The database is created automatically at `backend/data/product-exam.db` when the server starts.

## Architecture

```text
ProductExam/
├── frontend/
│   ├── index.html
│   ├── script.js
│   └── style.css
├── backend/
│   ├── src/
│   │   ├── business-rules/
│   │   │   ├── domain/
│   │   │   │   ├── Product.js
│   │   │   │   └── ShoppingCart.js
│   │   │   └── services/
│   │   │       └── ProductService.js
│   │   ├── controllers/
│   │   ├── errors/
│   │   ├── middleware/
│   │   ├── repositories/
│   │   ├── routes/
│   │   ├── app.js
│   │   ├── config.js
│   │   └── server.js
│   ├── test/
│   ├── data/
│   ├── ecosystem.config.cjs
│   └── package.json
├── docs/
└── evidence/
```

## Clean Code Design

- Names communicate intent.
- Functions and classes have focused responsibilities.
- Business rules are independent from HTTP and presentation concerns.
- Domain objects validate their own state.
- The controller, service, and repository are connected through dependency injection.
- Errors are handled consistently by centralized middleware.
- Business rules and REST endpoints have automated tests.

## Run Locally

```powershell
cd backend
npm install
npm start
```

Open:

```text
http://localhost:3016/
```

Public AWS deployment:

```text
http://3.131.36.236/
```

## Run Tests

```powershell
cd backend
npm test
```

## Production Process

The backend includes a PM2 configuration for AWS EC2:

```bash
cd backend
pm2 start ecosystem.config.cjs
pm2 save
```

## Documentation

- [Class diagram](docs/CLASS_DIAGRAM.md)
- [URL, URI/endpoint design, and web page URL](docs/URL_ENDPOINT_DESIGN.md)
- [AWS EC2 deployment guide](docs/AWS_EC2_DEPLOYMENT.md)
